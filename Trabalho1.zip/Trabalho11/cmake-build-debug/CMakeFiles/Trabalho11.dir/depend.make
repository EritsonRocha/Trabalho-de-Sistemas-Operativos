# Empty dependencies file for Trabalho11.
# This may be replaced when dependencies are built.
