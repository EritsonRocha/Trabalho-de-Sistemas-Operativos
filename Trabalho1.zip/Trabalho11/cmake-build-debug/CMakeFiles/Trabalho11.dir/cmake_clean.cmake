file(REMOVE_RECURSE
  "CMakeFiles/Trabalho11.dir/link.d"
  "CMakeFiles/Trabalho11.dir/main.c.o"
  "CMakeFiles/Trabalho11.dir/main.c.o.d"
  "Trabalho11"
  "Trabalho11.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/Trabalho11.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
