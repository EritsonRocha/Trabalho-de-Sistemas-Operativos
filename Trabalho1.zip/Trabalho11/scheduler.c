#include "scheduler.h"

#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "msg.h"

static const char *SCHED_NAMES[] = { "FIFO", "SJF", "RR", "MLFQ", NULL };
static sched_algo_en sched_algo = SCHED_FIFO;

// MLFQ: número de níveis (0 = prioridade mais alta) e período do boost.
#define MLFQ_LEVELS   3
#define MLFQ_BOOST_MS 12000
static uint32_t last_boost_ms = 0;

int set_sched_algo(const char *name) {
    for (int i = 0; SCHED_NAMES[i] != NULL; i++) {
        if (strcasecmp(SCHED_NAMES[i], name) == 0) {
            sched_algo = (sched_algo_en) i;
            return sched_algo;
        }
    }
    return -1;
}

const char *get_sched_algo_str(void) {
    return SCHED_NAMES[sched_algo];
}

/**
 * Send DONE to the application and move the finished burst to the command queue.
 */
static void finish_burst(uint32_t current_time_ms, queue_t *cq, pcb_t *task) {
    msg_t msg = {
        .pid = task->pid,
        .request = PROCESS_REQUEST_DONE,
        .time_ms = current_time_ms
    };
    if (write(task->sockfd, &msg, sizeof(msg_t)) != sizeof(msg_t)) {
        perror("write");
    }
    enqueue_pcb(cq, task);
}

/**
 * MLFQ boost: todos os processos prontos (e o que está no CPU) voltam ao nível 0.
 */
static void mlfq_boost(queue_t *rq, pcb_t *cpu_task) {
    for (queue_elem_t *e = rq->head; e != NULL; e = e->next) {
        e->pcb->level = 0;
        printf("[MLFQ] PID %d voltou ao nível 0 (boost)\n", e->pcb->pid);    }
    if (cpu_task) {
        cpu_task->level = 0;
        printf("[MLFQ] PID %d voltou ao nível 0 (boost, estava no CPU)\n", cpu_task->pid);
    }
}

/**
 * Escreve no ecrã a decisão de escalonamento: que processo foi escolhido para o CPU e porquê.
 * Chamada depois do dequeue, por isso rq->size é o número de processos que continuam à espera.
 */
static void log_dispatch(uint32_t current_time_ms, queue_t *rq, pcb_t *task) {
    uint32_t restante_ms = task->time_ms - task->ellapsed_time_ms;

    if (sched_algo == SCHED_FIFO) {
        printf("[FIFO] t=%u ms: PID %d é o primeiro da fila e vai para o CPU (burst de %u ms, %zd à espera)\n",
            current_time_ms, task->pid, task->time_ms, rq->size);
    } else if (sched_algo == SCHED_SJF) {
        printf("[SJF] t=%u ms: PID %d tem o menor burst (%u ms) entre %zd prontos e vai para o CPU\n",
            current_time_ms, task->pid, task->time_ms, rq->size + 1);
    } else if (sched_algo == SCHED_RR) {
        printf("[RR] t=%u ms: PID %d vai para o CPU por um time-slice de %u ms (faltam %u ms de CPU, %zd à espera)\n",
            current_time_ms, task->pid, TIME_SLICE_MS, restante_ms, rq->size);
    } else {
        printf("[MLFQ] t=%u ms: PID %d (nível %u) tem a prioridade mais alta e vai para o CPU (faltam %u ms de CPU, %zd à espera)\n",
            current_time_ms, task->pid, task->level, restante_ms, rq->size);
    }

    // Tempo de resposta: só na 1.ª vez que o processo vai ao CPU.
    // = (instante em que chega ao CPU) - (instante em que chegou o 1.º RUN).
    // Estas linhas são as que se usam no relatório (procurar "tempo de resposta").
    if (!task->started) {
        task->started = 1;
        task->first_cpu_ms = current_time_ms;
        printf("[%s] t=%u ms: PID %d tempo de resposta = %u ms (chegou a %u ms, 1.ª vez no CPU a %u ms)\n",
            get_sched_algo_str(), current_time_ms, task->pid,
            task->first_cpu_ms - task->arrival_ms, task->arrival_ms, task->first_cpu_ms);
    }
}

/**
 * FIFO (First-In, First-Out) — não preemptivo.
 *
 * O primeiro processo a chegar à ready queue corre até o seu burst de CPU
 * terminar; só então o CPU fica livre para o processo seguinte.
 *
 * Resumo dos 4 algoritmos (escolhidos com `--sched`):
 *   FIFO - escolhe o que está há mais tempo na ready queue (dequeue_pcb). Não preemptivo.
 *   SJF  - escolhe o de menor burst de CPU (dequeue_pcb_sjf em queue.c). Não preemptivo.
 *   RR   - escolhe a cabeça da fila, mas ao fim de TIME_SLICE_MS volta para o fim da fila.
 *   MLFQ - como o RR, mas escolhe o de menor `level` (dequeue_pcb_mlfq). Quem gasta o
 *          slice todo desce de nível; quem bloqueia (E/S) antes do fim mantém o nível;
 *          a cada MLFQ_BOOST_MS todos voltam ao nível 0 (evita starvation).
 *
 * Esta função é chamada uma vez por tick (TICKS_MS = 10 ms) e faz sempre, por ordem:
 *   1) (só MLFQ) verifica se é altura do boost;
 *   2) se há processo no CPU: conta o tempo; se o burst acabou -> DONE; se o slice
 *      acabou (RR/MLFQ) -> preempção, volta ao fim da ready queue;
 *   3) se o CPU está livre: escolhe o próximo processo (a decisão do algoritmo)
 *      e escreve no ecrã o que decidiu (log_dispatch).
 */
int scheduler(uint32_t current_time_ms, queue_t *rq, queue_t *cq, pcb_t **cpu_task) {
    if (sched_algo == SCHED_MLFQ) {
        if (*cpu_task == NULL && rq->head == NULL) {
            // Sem contenção: o relógio do boost só conta enquanto há processos a disputar o CPU.
            last_boost_ms = current_time_ms;
        } else if (current_time_ms - last_boost_ms >= MLFQ_BOOST_MS) {
            mlfq_boost(rq, *cpu_task);
            last_boost_ms = current_time_ms;
        }
    }

    if (*cpu_task) {
        (*cpu_task)->ellapsed_time_ms += TICKS_MS;
        if ((*cpu_task)->ellapsed_time_ms >= (*cpu_task)->time_ms) {
            printf("[%s] t=%u ms: PID %d terminou o burst de CPU (%u ms)\n",
                get_sched_algo_str(), current_time_ms, (*cpu_task)->pid, (*cpu_task)->time_ms);
            finish_burst(current_time_ms, cq, *cpu_task);
            *cpu_task = NULL;
        } else if ((sched_algo == SCHED_RR || sched_algo == SCHED_MLFQ) && current_time_ms - (*cpu_task)->slice_start_ms >= TIME_SLICE_MS) {

            // RR / MLFQ: o time-slice acabou sem o burst terminar -> preempção.
            // O processo vai para o fim da ready queue e o CPU fica livre.
            // MLFQ: gastou o slice todo, por isso desce um nível.

            if (sched_algo == SCHED_MLFQ && (*cpu_task)->level < MLFQ_LEVELS - 1) {
                (*cpu_task)->level++;
                printf("[MLFQ] t=%u ms: PID %d gastou o time-slice e desceu para o nível %u\n",
                    current_time_ms, (*cpu_task)->pid, (*cpu_task)->level);
            } else if (sched_algo == SCHED_MLFQ) {
                printf("[MLFQ] t=%u ms: PID %d gastou o time-slice mas já está no último nível (%u), fica no nível %u\n",
                    current_time_ms, (*cpu_task)->pid, (*cpu_task)->level, (*cpu_task)->level);
            } else {
                printf("[RR] t=%u ms: PID %d gastou o time-slice de %u ms e vai para o fim da fila (faltam %u ms de CPU)\n",
                    current_time_ms, (*cpu_task)->pid, TIME_SLICE_MS,
                    (*cpu_task)->time_ms - (*cpu_task)->ellapsed_time_ms);
            }
            if (enqueue_pcb(rq, *cpu_task)) {
                *cpu_task = NULL;
            }
        }
    }

    if (*cpu_task == NULL) {

        if (sched_algo == SCHED_FIFO) { //FIFO
            *cpu_task = dequeue_pcb(rq);
        }

        if (sched_algo == SCHED_SJF) { //SJF
            *cpu_task = dequeue_pcb_sjf(rq);
        }

        if (sched_algo == SCHED_RR) { //RR
            *cpu_task = dequeue_pcb_rr(rq);
        }

        if (sched_algo == SCHED_MLFQ) {
            *cpu_task = dequeue_pcb_mlfq(rq);
        }

        if (*cpu_task) {
            log_dispatch(current_time_ms, rq, *cpu_task);
            (*cpu_task)->slice_start_ms = current_time_ms;
            return 1;
        }
    }
    return 0;
}